export KALDI_ROOT=`pwd`/../../..
export PATH=$KALDI_ROOT/src/nnetbin/:$PWD/utils/:$KALDI_ROOT/src/bin:$KALDI_ROOT/tools/openfst/bin:$KALDI_ROOT/src/fstbin/:$KALDI_ROOT/src/gmmbin/:$KALDI_ROOT/src/featbin/:$KALDI_ROOT/src/lm/:$KALDI_ROOT/src/sgmmbin/:$KALDI_ROOT/src/sgmm2bin/:$KALDI_ROOT/src/fgmmbin/:$KALDI_ROOT/src/latbin/:$KALDI_ROOT/src/online2bin/:$KALDI_ROOT/src/ivectorbin/:$KALDI_ROOT/src/nnet2bin/:$KALDI_ROOT/src/lmbin/:$PWD:$PATH

# Speech corpus should be stored here
export DATA_ROOT=./data/train
export mfccdir=${DATA_ROOT}/mfcc

if [ -z $DATA_ROOT ]; then
  echo "Data is missing - please recheck"
  exit 1
fi

# . ../../../tools/env.sh

# Make sure that MITLM shared libs are found by the dynamic linker/loader
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$(pwd)/tools/mitlm-svn/lib

# Needed for "correct" sorting
export LC_ALL=C
