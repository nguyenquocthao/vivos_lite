#!/bin/bash

#################################################################
#                                                               #
# Copyright 2016 Luong Hieu Thi,                                #
#           2016 Artificial Intelligent Laboratory              #
#                Vietnam National University. Ho Chi Minh City  #
#                University of Science,                         #
#                                                               #
#################################################################


. ./path.sh || exit 1
. ./cmd.sh || exit 1


# Acoustic model parameters

numLeavesTri1=5000
numGaussTri1=15000

numLeavesMLLT=5000
numGaussMLLT=15000

# Variables
njobs=2
pos_dep_phones=false


stage=0

# The user of this script could change some of the above parameters. Example:
. utils/parse_options.sh || exit 1
[[ $# -ge 1 ]] && { echo "Unexpected arguments"; exit 1; } 

echo ============================================================================
echo "                Data & Lexicon & Language Preparation                     "
echo ============================================================================


# change this evertime you run
if [ $stage -le 0 ]; then
  for x in test train; do
    local/ailab_prepare_data.sh warehouse/$x || exit 1
    mfccdir=warehouse/$x/mfcc  
    utils/fix_data_dir.sh warehouse/$x || exit 1;
    steps/make_mfcc.sh --cmd "$train_cmd" --nj "$njobs" \
      warehouse/$x warehouse/$x/exp/make_mfcc $mfccdir || exit 1;
    steps/compute_cmvn_stats.sh warehouse/$x warehouse/$x/exp/make_mfcc $mfccdir || exit 1;
  done

  mkdir -p data/{train,local}
  ./utils/combine_data.sh data/train warehouse/train
  ./utils/combine_data.sh data/test warehouse/test
fi


# Prepare language
if [ $stage -le 1 ]; then
  cp requirements/vocab-full.txt data/local

  local/ailab_prepare_dict.sh requirements/tiengviet.dct || exit 1

  utils/prepare_lang.sh --position-dependent-phones $pos_dep_phones \
  data/local/dict '!SIL' data/local/lang data/lang || exit 1

  # Prepare G.fst
  tmpdir=data/lm_tmp
  mkdir -p $tmpdir

  cat requirements/lm.arpa | \
    utils/find_arpa_oovs.pl data/lang/words.txt > $tmpdir/oovs.txt

  cat requirements/lm.arpa | \
    grep -v '<s> <s>' | \
    grep -v '</s> <s>' | \
    grep -v '</s> </s>' | \
    arpa2fst - | fstprint | \
    utils/remove_oovs.pl $tmpdir/oovs.txt | \
    utils/eps2disambig.pl | utils/s2eps.pl | fstcompile --isymbols=data/lang/words.txt \
      --osymbols=data/lang/words.txt  --keep_isymbols=false --keep_osymbols=false | \
    fstrmepsilon | fstarcsort --sort_type=ilabel > data/lang/G.fst
  fstisstochastic data/lang/G.fst

fi


echo ============================================================================
echo "                     MonoPhone Training & Decoding                        "
echo ============================================================================

if [ $stage -le 2 ]; then
  utils/subset_data_dir.sh --shortest data/train 1000 data/train_1kshort  || exit 1;
  steps/train_mono.sh --nj "$njobs" --cmd "$train_cmd" \
    data/train_1kshort data/lang exp/mono0a  || exit 1;

  utils/mkgraph.sh --mono data/lang exp/mono0a exp/mono0a/graph
  steps/decode.sh --nj "$njobs" --cmd "$decode_cmd" \
    exp/mono0a/graph data/test exp/mono0a/decode_test

  steps/align_si.sh --nj "$njobs" --cmd "$train_cmd" \
    data/train data/lang exp/mono0a exp/mono0a_ali || exit 1;
fi



echo ============================================================================
echo "           tri1 : Deltas + Delta-Deltas Training & Decoding               "
echo ============================================================================

if [ $stage -le 3 ]; then
  steps/train_deltas.sh --cmd "$train_cmd" \
    $numLeavesTri1 $numGaussTri1 data/train data/lang exp/mono0a_ali exp/tri1 || exit 1;

  utils/mkgraph.sh data/lang exp/tri1 exp/tri1/graph || exit 1;

  steps/decode.sh --config conf/decode.config --nj "$njobs" --cmd "$decode_cmd" \
    exp/tri1/graph data/test exp/tri1/decode_test || exit 1;
fi


echo ============================================================================
echo "                 tri2 : LDA + MLLT Training & Decoding                    "
echo ============================================================================
if [ $stage -le 4 ]; then
  steps/align_si.sh --nj $njobs --cmd "$train_cmd" \
    data/train data/lang exp/tri1 exp/tri1_ali || exit 1;

  steps/train_lda_mllt.sh --cmd "$train_cmd" \
    --splice-opts "--left-context=3 --right-context=3" \
    $numLeavesMLLT $numGaussMLLT data/train data/lang exp/tri1_ali exp/tri2 || exit 1;
  
  utils/mkgraph.sh data/lang exp/tri2 exp/tri2/graph

  steps/decode.sh --config conf/decode.config --nj "$njobs" --cmd "$decode_cmd" \
    exp/tri2/graph data/test exp/tri2/decode_test
fi

