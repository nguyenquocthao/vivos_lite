#!/bin/bash

#################################################################
#                                                               #
# Copyright 2016 Luong Hieu Thi,                                #
#           2016 Artificial Intelligent Laboratory              #
#                Vietnam National University. Ho Chi Minh City  #
#                University of Science,                         #
#                                                               #
#################################################################

source path.sh

. utils/parse_options.sh

if [ $# != 1 ]; then
  echo "Usage: $0 <pronunciation-dictionary>";
  exit 1;
fi

# Get arguments
dictionary=$1


# Prepare neccesary directory
locdata=data/local
locdict=$locdata/dict



echo "===== AILAB: Prepare lexicon ====="

mkdir -p $locdict
# Get the pre-prepare dictionary
cp $dictionary $locdict/tiengviet.dct

# Searching for OOV words
echo "--- Searching for OOV words ..."
gawk 'NR==FNR{words[$1]; next;} !($1 in words)' \
  $locdict/tiengviet.dct $locdata/vocab-full.txt |\
  egrep -v '<.?s>' > $locdict/vocab-oov.txt

gawk 'NR==FNR{words[$1]; next;} ($1 in words)' \
  $locdata/vocab-full.txt $locdict/tiengviet.dct |\
  egrep -v '<.?s>' > $locdict/lexicon-iv.txt

wc -l $locdict/vocab-oov.txt
wc -l $locdict/lexicon-iv.txt

# Prepare procounciation for OOV words
echo "--- Preparing pronunciations for OOV words ..."
echo "--- Can't do that!!!!!!!!!!!!!!!!!!!!!!!!! ..."

# Get the Lexion
cat $locdict/lexicon-iv.txt | sort > $locdict/lexicon.txt

#Prepare the phones list
echo "--- Prepare phone lists ..."
echo SIL > $locdict/silence_phones.txt
echo SIL > $locdict/optional_silence.txt
grep -v -w sil $locdict/lexicon.txt | \
  awk '{for(n=2;n<=NF;n++) { p[$n]=1; }} END{for(x in p) {print x}}' |\
  sort > $locdict/nonsilence_phones.txt


echo "--- Adding SIL to the lexicon ..."
echo -e "!SIL\tSIL" >> $locdict/lexicon.txt


# Some downstream scripts expect this file exists, even if empty
touch $locdict/extra_questions.txt

echo "===== Finished pronunciation dictionary ====="
