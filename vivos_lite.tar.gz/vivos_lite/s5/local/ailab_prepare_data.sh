#!/bin/bash

#################################################################
#                                                               #
# Copyright 2016 Luong Hieu Thi,                                #
#           2016 Artificial Intelligent Laboratory              #
#                Vietnam National University. Ho Chi Minh City  #
#                University of Science,                         #
#                                                               #
#################################################################

source path.sh

echo "===== AILAB: Prepare necessary files fo data folder ====="

. utils/parse_options.sh

if [ $# != 1 ]; then
  echo "Usage: $0 <data-directory>";
  exit 1;
fi


data_dir=$1

locdata=$data_dir/local
loctmp=$locdata/tmp

rm -rf $loctmp >/dev/null 2>&1

mkdir -p $locdata $loctmp

# Get all speaker ID
ls $data_dir/waves | sort -u > $loctmp/speakers_all.txt

# Prepare trans

rm ${locdata}/spk2gender 2>/dev/null

while read spkname; do
  dir=$data_dir/waves/$spkname

  grep -m 1 "${spkname} " $data_dir/genders.txt >> $locdata/spk2gender.tmp

  # Prepare Transcript
  while read w; do
    id=${w%.wav}
    w=$dir/$w
	
    echo "$id $w" >> ${loctmp}/test_wav.scp.unsorted
    echo "$id $spkname" >> $loctmp/test.utt2spk.unsorted
    grep -m 1 "${id}" ${data_dir}/prompts.txt >> ${loctmp}/test_trans.txt.unsorted
  done < <( ls $dir )
done < $loctmp/speakers_all.txt
  

# filter out the audio for which there is no proper transcript
gawk 'NR==FNR{trans[$1]; next} ($1 in trans)' FS=" " \
 ${loctmp}/test_trans.txt.unsorted ${loctmp}/test_wav.scp.unsorted |\
 sort -k1 > $data_dir/wav.scp
 
gawk 'NR==FNR{trans[$1]; next} ($1 in trans)' FS=" " \
 ${loctmp}/test_trans.txt.unsorted $loctmp/test.utt2spk.unsorted |\
 sort -k1 > $data_dir/utt2spk
 
sort -k1 < ${loctmp}/test_trans.txt.unsorted > $data_dir/text

echo "--- Preparing test.spk2utt ..."
cat $data_dir/text |\
 cut -f1 -d' ' |\
 gawk 'BEGIN {FS="_"}
       {names[$1]=names[$1] " " $0;}
       END {for (k in names) {print k, names[k];}}' | sort -k1 > $data_dir/spk2utt

gawk '{spk[$1]=$2;} END{for (s in spk) print s " " spk[s]}' \
  $locdata/spk2gender.tmp | sort -k1 > $data_dir/spk2gender

echo "===== AILAB: Finished prepare data for ${data_dir} ====="
